﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace formulario_de_cadastro
{
    public class Cliente
    {
        public string Nome { get; set; } = "";
        public string CPF { get; set; } = "";
        public string Email { get; set; } = "";
        public string Telefone { get; set; } = "";
        public string Endereco { get; set; } = "";
        public string CEP { get; set; } = "";
        public string Estado { get; set; } = "";
        public string Cidade { get; set; } = "";
    }
}
